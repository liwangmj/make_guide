package com.example.web;

import junit.framework.TestCase;

/**
 * Created by wjx on 15/7/5.
 */
public class UserControllerTest extends TestCase {

    public void testGetUser() throws Exception {
    }
}