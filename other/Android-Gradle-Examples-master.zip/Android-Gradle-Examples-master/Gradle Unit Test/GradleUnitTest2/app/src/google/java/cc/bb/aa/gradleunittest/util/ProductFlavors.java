package cc.bb.aa.gradleunittest.util;

/**
 * <p></p>
 * <p>Created by yanglw on 2015-02-25 10:19.</p>
 */
public class ProductFlavors
{
    public static int addGoogle(int a, int b)
    {
        return a + b;
    }
}
