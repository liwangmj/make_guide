package aa.bb.cc;

/**
 * <p></p>
 * <p>Created by yanglw on 2014-12-31 14:46.</p>
 */
public class Price
{
    public static String getName()
    {
        return "$ 2.0";
    }
}
