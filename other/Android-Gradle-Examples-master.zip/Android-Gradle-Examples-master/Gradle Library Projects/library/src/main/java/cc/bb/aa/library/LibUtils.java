package cc.bb.aa.library;

/**
 * <p></p>
 * <p>Created by yanglw on 2014-12-30 16:31.</p>
 */
public class LibUtils
{
    public static void f()
    {
        System.out.printf("hello world");
    }
}
