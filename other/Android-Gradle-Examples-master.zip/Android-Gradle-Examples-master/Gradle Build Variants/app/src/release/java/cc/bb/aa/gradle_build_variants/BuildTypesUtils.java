package cc.bb.aa.gradle_build_variants;

/**
 * <p></p>
 * <p>Created by yanglw on 2014-12-31 14:46.</p>
 */
public class BuildTypesUtils
{
    public static String getBuildTypesName()
    {
        return "release";
    }
}
