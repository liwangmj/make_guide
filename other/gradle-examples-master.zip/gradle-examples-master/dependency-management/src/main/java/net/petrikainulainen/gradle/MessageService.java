package net.petrikainulainen.gradle;

/**
 * @author Petri Kainulainen
 */
public class MessageService {

    public String getMessage() {
        return "Hello World!";
    }
}
