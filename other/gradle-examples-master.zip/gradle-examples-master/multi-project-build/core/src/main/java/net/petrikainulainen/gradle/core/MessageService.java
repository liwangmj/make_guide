package net.petrikainulainen.gradle.core;

/**
 * @author Petri Kainulainen
 */
public class MessageService {

    public String getMessage() {
        return "Hello World!";
    }
}
