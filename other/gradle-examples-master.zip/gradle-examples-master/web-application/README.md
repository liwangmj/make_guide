This is an example application of my blog post:

* [Getting Started with Gradle: Creating a Web Application Project](http://www.petrikainulainen.net/programming/gradle/getting-started-with-gradle-creating-a-web-application-project/)

You can run the application by running the following command at command prompt:

        gradle appStart

This command will run the web application by using the Jetty 9 servlet container. You
can access the application by using the url: _http://localhost:8080/_.

You can stop the application by running the following command at command prompt:

        gradle appStop

